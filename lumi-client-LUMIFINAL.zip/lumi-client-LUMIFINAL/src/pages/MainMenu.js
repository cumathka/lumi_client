import React from 'react';
import Footer from '../components/Footer'
import SelectMenu from '../components/SelectMenu'
const  MainMenu = () => {
  return (
    <>
    <SelectMenu/>
      <br />
    <Footer/>
    </>
  )
}
export default MainMenu